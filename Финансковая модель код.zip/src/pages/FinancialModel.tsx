import React, { useMemo } from 'react';
import { formatCurrencyRub } from '@/shared/lib/format';
import { PlusIcon } from '@/shared/components/Icons';
import { Button, Select } from '@/shared/ui';
import { MetricCard } from '@/shared/components/MetricCard';
import { getToken } from '@/shared/lib/tokens';
import { useFinancialModel } from './financial-model/hooks/useFinancialModel';
import { CreditCard, ExpenseCard, ExpenseForm, CreditFormModal } from './financial-model/components';
import { getMonthLabel } from './financial-model/utils';
import { useGoalsStore } from '@/store/goals';

export function FinancialModel(): React.ReactElement {
	const iconSizeMd = useMemo(() => getToken('--icon-size-md', 20), []);

	const {
		credits,
		availableMonths,
		selectedMonth,
		setSelectedMonth,
		currentMonthData,
		totalExpenses,
		totalCredits,
		totalMonthlyPayments,
		showForm,
		setShowForm,
		editing,
		setEditing,
		editingExpense,
		name,
		setName,
		amount,
		setAmount,
		monthlyPayment,
		setMonthlyPayment,
		interestRate,
		setInterestRate,
		notes,
		setNotes,
		paymentDate,
		setPaymentDate,
		newExpenseName,
		setNewExpenseName,
		newExpenseAmount,
		setNewExpenseAmount,
		handleSubmit,
		handleEdit,
		handleDelete,
		handleTogglePaid,
		handleAddExpense,
		handleEditExpense,
		handleSaveExpense,
		handleCancelEdit,
	} = useFinancialModel();

	const updateMonthlyExpense = useGoalsStore((s) => s.updateMonthlyExpense);
	const removeMonthlyExpense = useGoalsStore((s) => s.removeMonthlyExpense);

	return (
		<div className="page">
			<div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
				<div>
					<h1 className="page-title">Финансовая модель</h1>
					<p className="page-subtitle">Управление кредитами и финансовыми целями по месяцам</p>
				</div>
				<Button
					onClick={() => {
						setEditing(null);
						setShowForm(true);
					}}
					variant="primary"
				>
					<span style={{ display: 'inline-flex', alignItems: 'center', gap: 'var(--space-sm)' }}>
						<PlusIcon size={iconSizeMd} color="currentColor" />
						<span>Добавить кредит</span>
					</span>
				</Button>
			</div>

			{/* Список кредитов */}
			<div style={{ marginTop: 'var(--space-lg)' }}>
				<h2 style={{ marginBottom: 'var(--space-md)' }}>Кредиты и кредитные карты</h2>
				<div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)' }}>
					{credits.map((credit) => (
						<CreditCard
							key={credit.id}
							credit={credit}
							onEdit={handleEdit}
							onDelete={handleDelete}
							onTogglePaid={handleTogglePaid}
						/>
					))}
					{credits.length === 0 && (
						<div
							style={{
								textAlign: 'center',
								padding: 'var(--space-xl)',
								color: 'var(--muted)',
							}}
						>
							Нет кредитов. Добавьте первый!
						</div>
					)}
				</div>
			</div>

			{/* Финансовые цели по месяцам */}
			<div
				style={{
					marginTop: 'var(--space-lg)',
					background: 'var(--panel)',
					border: 'var(--border-width) solid var(--border)',
					borderRadius: 'var(--radius-lg)',
					padding: 'var(--space-lg)',
				}}
			>
				<h2 style={{ marginTop: 0, marginBottom: 'var(--space-md)' }}>Финансовые цели по месяцам</h2>
				<div style={{ marginBottom: 'var(--space-md)' }}>
					<label style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-sm)' }}>
						<span style={{ fontSize: 'var(--font-size-sm)', fontWeight: 'var(--font-weight-semibold)', color: 'var(--text)' }}>
							Выберите месяц
						</span>
						<Select
							size="xs"
							value={selectedMonth}
							onChange={(e) => setSelectedMonth((e.target as HTMLSelectElement).value)}
							style={{ minWidth: 'var(--reports-month-label-min-width)' }}
						>
							{availableMonths.map((monthKey) => (
								<option key={monthKey} value={monthKey}>
									{getMonthLabel(monthKey)}
								</option>
							))}
						</Select>
					</label>
				</div>

				<div
					style={{
						marginBottom: 'var(--space-md)',
						padding: 'var(--space-md)',
						background: 'var(--bg)',
						borderRadius: 'var(--radius-md)',
						border: 'var(--border-width) solid var(--border)',
					}}
				>
					<div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-md)' }}>
						<div style={{ fontSize: 'var(--font-size-sm)', fontWeight: 'var(--font-weight-semibold)', color: 'var(--text)' }}>
							Расходы за {getMonthLabel(selectedMonth)}
						</div>
						<div style={{ fontSize: 'var(--font-size-xl)', fontWeight: 'var(--font-weight-bold)', color: 'var(--accent)' }}>
							{formatCurrencyRub(totalExpenses)}
						</div>
					</div>

					<div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-sm)', marginBottom: 'var(--space-md)' }}>
						{currentMonthData.expenses && currentMonthData.expenses.length > 0 ? (
							currentMonthData.expenses.map((expense) => {
								const isEditing = editingExpense?.expenseId === expense.id;
								return isEditing ? (
									<div
										key={expense.id}
										style={{
											display: 'flex',
											alignItems: 'center',
											gap: 'var(--space-sm)',
											padding: 'var(--space-sm)',
											background: 'var(--panel)',
											borderRadius: 'var(--radius-md)',
											border: 'var(--border-width) solid var(--border)',
										}}
									>
										<ExpenseForm
											name={newExpenseName}
											amount={newExpenseAmount}
											onNameChange={setNewExpenseName}
											onAmountChange={setNewExpenseAmount}
											onSubmit={handleSaveExpense}
											onCancel={handleCancelEdit}
											isEditing={true}
										/>
									</div>
								) : (
									<ExpenseCard
										key={expense.id}
										expense={expense}
										isEditing={false}
										onToggleComplete={(completed) => updateMonthlyExpense(selectedMonth, expense.id, { completed })}
										onEdit={() => handleEditExpense(selectedMonth, expense.id)}
										onDelete={() => {
											if (window.confirm('Удалить расход?')) {
												removeMonthlyExpense(selectedMonth, expense.id);
											}
										}}
									/>
								);
							})
						) : (
							<div
								style={{
									textAlign: 'center',
									padding: 'var(--space-lg)',
									color: 'var(--muted)',
									fontSize: 'var(--font-size-sm)',
								}}
							>
								Нет расходов для этого месяца. Добавьте первый расход ниже.
							</div>
						)}
					</div>

					{!editingExpense && (
						<ExpenseForm
							name={newExpenseName}
							amount={newExpenseAmount}
							onNameChange={setNewExpenseName}
							onAmountChange={setNewExpenseAmount}
							onSubmit={handleAddExpense}
						/>
					)}
				</div>
			</div>

			{/* Сводка */}
			<div style={{ marginTop: 'var(--space-lg)', display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 'var(--space-md)' }}>
				<MetricCard title="Общая сумма кредитов" value={formatCurrencyRub(totalCredits)} valueColor="var(--red)" border={false} />
				<MetricCard title="Ежемесячные платежи" value={formatCurrencyRub(totalMonthlyPayments)} valueColor="var(--red)" border={false} />
			</div>

			{/* Форма добавления/редактирования */}
			<CreditFormModal
				open={showForm}
				editing={editing}
				name={name}
				amount={amount}
				monthlyPayment={monthlyPayment}
				interestRate={interestRate}
				notes={notes}
				paymentDate={paymentDate}
				onNameChange={setName}
				onAmountChange={setAmount}
				onMonthlyPaymentChange={setMonthlyPayment}
				onInterestRateChange={setInterestRate}
				onNotesChange={setNotes}
				onPaymentDateChange={setPaymentDate}
				onSubmit={handleSubmit}
				onClose={() => {
					setShowForm(false);
					setEditing(null);
				}}
			/>
		</div>
	);
}
