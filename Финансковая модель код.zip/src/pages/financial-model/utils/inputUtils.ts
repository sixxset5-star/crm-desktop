import { safeEval } from '@/shared/lib/mathParser';

/**
 * Обрабатывает blur событие для числовых инпутов с поддержкой математических выражений
 * Если значение содержит математические операторы, вычисляет результат
 */
export function handleNumericInputBlur(
	value: string,
	onChange: (value: string) => void
): void {
	const trimmed = value.trim();
	if (trimmed && /[+\-*/]/.test(trimmed)) {
		const result = safeEval(trimmed);
		if (result !== null && isFinite(result)) {
			onChange(String(Math.round(result)));
		}
	}
}





