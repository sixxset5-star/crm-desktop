import React, { useMemo } from 'react';
import type { Credit } from '@/store/goals';
import { Modal, ModalFooter } from '@/shared/ui/Modal';
import { TextInput, TextArea } from '@/shared/ui';
import { getToken } from '@/shared/lib/tokens';
import { handleNumericInputBlur } from '../utils';

type CreditFormModalProps = {
	open: boolean;
	editing: Credit | null;
	name: string;
	amount: string;
	monthlyPayment: string;
	interestRate: string;
	notes: string;
	paymentDate: string;
	onNameChange: (value: string) => void;
	onAmountChange: (value: string) => void;
	onMonthlyPaymentChange: (value: string) => void;
	onInterestRateChange: (value: string) => void;
	onNotesChange: (value: string) => void;
	onPaymentDateChange: (value: string) => void;
	onSubmit: (e: React.FormEvent) => void;
	onClose: () => void;
};

export function CreditFormModal({
	open,
	editing,
	name,
	amount,
	monthlyPayment,
	interestRate,
	notes,
	paymentDate,
	onNameChange,
	onAmountChange,
	onMonthlyPaymentChange,
	onInterestRateChange,
	onNotesChange,
	onPaymentDateChange,
	onSubmit,
	onClose,
}: CreditFormModalProps): React.ReactElement {
	const modalWidth = useMemo(() => getToken('--modal-width-lg', 700), []);

	if (!open) return null;

	const handleAmountBlur = (e: React.FocusEvent<HTMLInputElement>) => {
		handleNumericInputBlur(e.target.value, onAmountChange);
	};

	const handleMonthlyPaymentBlur = (e: React.FocusEvent<HTMLInputElement>) => {
		handleNumericInputBlur(e.target.value, onMonthlyPaymentChange);
	};

	return (
		<Modal
			open={open}
			onClose={onClose}
			title={editing ? 'Редактировать кредит' : 'Новый кредит'}
			width={modalWidth}
			footer={
				<ModalFooter
					onCancel={onClose}
					onConfirm={() => (document.querySelector('form') as HTMLFormElement | null)?.requestSubmit()}
					confirmText="Сохранить"
					cancelText="Отмена"
				/>
			}
		>
			<form onSubmit={onSubmit} className="form-grid">
				<label className="col-span">
					<span>Название кредита/кредитной карты</span>
					<TextInput value={name} onChange={(e) => onNameChange((e.target as HTMLInputElement).value)} required />
				</label>
				<label>
					<span>Общая сумма кредита (Р)</span>
					<TextInput
						type="text"
						inputMode="numeric"
						value={amount}
						onChange={(e) => onAmountChange((e.target as HTMLInputElement).value)}
						onBlur={handleAmountBlur}
						placeholder="Необязательно (можно: 5000+1000)"
					/>
				</label>
				<label>
					<span>Ежемесячный платеж (Р)</span>
					<TextInput
						type="text"
						inputMode="numeric"
						value={monthlyPayment}
						onChange={(e) => onMonthlyPaymentChange((e.target as HTMLInputElement).value)}
						onBlur={handleMonthlyPaymentBlur}
						placeholder="Необязательно (можно: 5000+1000)"
					/>
				</label>
				<label>
					<span>Процентная ставка (%)</span>
					<TextInput
						type="number"
						inputMode="numeric"
						value={interestRate}
						onChange={(e) => onInterestRateChange((e.target as HTMLInputElement).value)}
						min="0"
						max="100"
						step="0.1"
						placeholder="Необязательно"
					/>
				</label>
				<label>
					<span>Дата платежа (число месяца)</span>
					<TextInput
						type="number"
						inputMode="numeric"
						min="1"
						max="31"
						value={paymentDate}
						onChange={(e) => {
							const val = (e.target as HTMLInputElement).value;
							// Разрешаем только числа от 1 до 31
							if (val === '' || (parseInt(val) >= 1 && parseInt(val) <= 31)) {
								onPaymentDateChange(val);
							}
						}}
						placeholder="Число месяца (1-31)"
					/>
				</label>
				<label className="col-span">
					<span>Заметки</span>
					<TextArea rows={3} value={notes} onChange={(e) => onNotesChange((e.target as HTMLTextAreaElement).value)} placeholder="Дополнительная информация" />
				</label>
			</form>
		</Modal>
	);
}

