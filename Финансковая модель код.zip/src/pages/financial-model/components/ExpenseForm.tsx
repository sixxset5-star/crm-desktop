import React from 'react';
import { Button, TextInput } from '@/shared/ui';
import { handleNumericInputBlur } from '../utils';

type ExpenseFormProps = {
	name: string;
	amount: string;
	onNameChange: (value: string) => void;
	onAmountChange: (value: string) => void;
	onSubmit: () => void;
	onCancel?: () => void;
	isEditing?: boolean;
};

export function ExpenseForm({
	name,
	amount,
	onNameChange,
	onAmountChange,
	onSubmit,
	onCancel,
	isEditing = false,
}: ExpenseFormProps): React.ReactElement {
	const handleAmountBlur = (e: React.FocusEvent<HTMLInputElement>) => {
		handleNumericInputBlur(e.target.value, onAmountChange);
	};

	const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
		if (e.key === 'Enter') {
			e.preventDefault();
			onSubmit();
		}
	};

	return (
		<div style={{ display: 'flex', gap: 'var(--space-sm)' }}>
			<TextInput
				type="text"
				size="xs"
				value={name}
				onChange={(e) => onNameChange((e.target as HTMLInputElement).value)}
				placeholder="Название расхода"
				style={{ flex: 1 }}
				onKeyDown={handleKeyDown}
			/>
			<TextInput
				type="text"
				size="xs"
				inputMode="numeric"
				value={amount}
				onChange={(e) => onAmountChange((e.target as HTMLInputElement).value)}
				onBlur={handleAmountBlur}
				placeholder="Сумма (Р)"
				style={{ width: 'var(--reports-task-count-min-width)' }}
				onKeyDown={handleKeyDown}
			/>
			<Button onClick={onSubmit} variant="primary" size="xs">
				{isEditing ? 'Сохранить' : 'Добавить расход'}
			</Button>
			{isEditing && onCancel && (
				<Button onClick={onCancel} variant="secondary" size="sm">
					Отмена
				</Button>
			)}
		</div>
	);
}

