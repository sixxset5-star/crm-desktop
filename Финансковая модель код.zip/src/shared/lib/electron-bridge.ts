import type { Task, TaskAssigneeHistory } from '@/types';
import type { Customer, Contractor } from '@/types';
import type { Income } from '@/types';
import type { Goal, MonthlyFinancialGoal, Credit } from '@/store/goals';
import type { Settings } from '@/store/settings';
import type { Calculation } from '@/store/calculator';
import type { TaxPaidFlag } from '@/store/taxes';
import type { ExtraWork } from '@/pages/workload/types/extra-work.types';
import type { IpcApi, IpcResult, AllowedEventChannel, EventPayloadMap } from './ipc-contract';

/**
 * Класс ошибки IPC с кодом для более детальной обработки
 */
export class IpcError extends Error {
	code: string;
	
	constructor(code: string, message?: string) {
		super(message || code);
		this.name = 'IpcError';
		this.code = code;
	}
}

// Хелпер для безопасного вызова IPC методов с обработкой ошибок
async function unwrap<T>(promise: Promise<IpcResult<T>>): Promise<T> {
	const res = await promise;
	if (!res.ok) {
		throw new IpcError(res.code, res.message);
	}
	return res.data;
}

// Хелпер для безопасного вызова методов, которые могут вернуть null
async function safeCall<T>(promise: Promise<T | null>, fallback: T): Promise<T> {
	try {
		const result = await promise;
		return result ?? fallback;
	} catch (error) {
		console.error('IPC call failed:', error);
		return fallback;
	}
}

export function subscribeToEvent<T extends AllowedEventChannel>(
	channel: T,
	callback: (payload: EventPayloadMap[T]) => void
): () => void {
	if (!window.crm?.onEvent) {
		return () => {};
	}
	return window.crm.onEvent(channel, callback) || (() => {});
}

export async function requestInstallUpdate(): Promise<void> {
	if (!window.crm?.installUpdate) return;
	try {
		await unwrap(window.crm.installUpdate());
	} catch (error) {
		console.error('installUpdate error:', error);
	}
}

export async function requestUpdateCheck(): Promise<void> {
	if (!window.crm?.checkForUpdates) return;
	try {
		await unwrap(window.crm.checkForUpdates());
	} catch (error) {
		console.error('checkForUpdates error:', error);
	}
}

export async function loadTasksFromDisk(): Promise<Task[]> {
	if (!window.crm) {
		console.error('[electron-bridge] window.crm is not available');
		return [];
	}
	try {
		console.log('[electron-bridge] Calling window.crm.loadTasks()...');
		const result = await window.crm.loadTasks();
		console.log('[electron-bridge] loadTasks result:', result);
		if (!result.ok) {
			console.warn('[electron-bridge] Tasks load returned error response', { 
				message: result.message, 
				code: result.code 
			});
			// Возвращаем пустой массив, не бросая исключение
			// Ошибка будет обработана в UI через существующий механизм
			return [];
		}
		console.log('[electron-bridge] Tasks loaded:', result.data?.length || 0);
		return result.data || [];
	} catch (error) {
		console.error('[electron-bridge] IPC call failed:', error);
		return [];
	}
}

export async function saveTasksToDisk(tasks: Task[]): Promise<void> {
	if (!window.crm) return;
	try {
		// Логируем информацию о платежах перед сохранением
		const tasksWithPayments = tasks.filter(t => t.payments && t.payments.length > 0);
		if (tasksWithPayments.length > 0) {
			console.log('[electron-bridge] Saving tasks with payments:', tasksWithPayments.map(t => ({
				id: t.id,
				title: t.title,
				paymentsCount: t.payments?.length || 0,
				payments: t.payments
			})));
		}
		
		// window.crm.saveTasks уже оборачивает tasks в { tasks }, поэтому передаем массив напрямую
		const result = await window.crm.saveTasks(tasks);
		if (!result.ok) {
			// НЕ бросаем исключение! Просто логируем предупреждение
			// Domain-сервис должен был нормализовать данные, но если ошибка всё равно вернулась,
			// значит данные действительно невалидны - просто пропускаем сохранение
			console.warn('[electron-bridge] Save tasks returned error response (data not saved)', { 
				message: result.message, 
				code: result.code 
			});
			return; // Ничего не сохраняем, но не падаем
		}
		// Успешное сохранение
		console.log('[electron-bridge] Tasks saved successfully', { 
			count: tasks.length,
			tasksWithPayments: tasksWithPayments.length
		});
	} catch (error) {
		// Только реальные исключения (network, IPC channel errors) логируем как ошибки
		console.error('[electron-bridge] IPC call failed (unexpected error):', error);
	}
}

export async function loadCustomersFromDisk(): Promise<Customer[]> {
	if (!window.crm) return [];
	try {
		const result = await window.crm.loadCustomers();
		if (!result.ok) {
			console.error('Failed to load customers:', result.message);
			return [];
		}
		return result.data;
	} catch (error) {
		console.error('IPC call failed:', error);
		return [];
	}
}

export async function loadContractorsFromDisk(): Promise<Contractor[]> {
	if (!window.crm) {
		console.warn('[electron-bridge] loadContractorsFromDisk: window.crm not available');
		return [];
	}
	try {
		console.log('[electron-bridge] Loading contractors from disk...');
		const result = await window.crm.loadContractors();
		if (!result.ok) {
			console.error('[electron-bridge] Failed to load contractors:', result.message, result.code);
			return [];
		}
		const contractors = result.data || [];
		console.log('[electron-bridge] Contractors loaded successfully:', {
			count: contractors.length,
			contractors: contractors.map(c => ({
				id: c.id,
				name: c.name,
				isActive: c.isActive,
				hasContacts: !!c.contacts && c.contacts.length > 0,
				hasContact: !!c.contact,
				createdAt: c.createdAt,
				updatedAt: c.updatedAt
			}))
		});
		return contractors;
	} catch (error) {
		console.error('[electron-bridge] IPC call failed:', error);
		return [];
	}
}

export async function saveContractorsToDisk(contractors: Contractor[]): Promise<void> {
	if (!window.crm) {
		console.warn('[electron-bridge] saveContractorsToDisk: window.crm not available');
		return;
	}
	try {
		if (!Array.isArray(contractors)) {
			console.error('[electron-bridge] saveContractorsToDisk: contractors is not an array', typeof contractors);
			return;
		}
		
		// Нормализуем данные: преобразуем null в undefined для опциональных полей
		const normalizedContractors = contractors.map(c => ({
			...c,
			contact: c.contact === null ? undefined : c.contact,
			avatar: c.avatar === null ? undefined : c.avatar,
			comment: c.comment === null ? undefined : c.comment,
			specialization: c.specialization === null ? undefined : c.specialization,
			rate: c.rate === null ? undefined : c.rate,
		}));
		
		console.log('[electron-bridge] Saving contractors to disk:', {
			count: normalizedContractors.length,
			contractors: normalizedContractors.map(c => ({
				id: c.id,
				name: c.name,
				isActive: c.isActive,
				hasContacts: !!c.contacts && c.contacts.length > 0,
				hasContact: !!c.contact,
				specialization: c.specialization,
				createdAt: c.createdAt,
				updatedAt: c.updatedAt
			}))
		});
		const result = await window.crm.saveContractors(normalizedContractors);
		if (!result.ok) {
			console.error('[electron-bridge] Save contractors returned error response (data not saved)', { 
				message: result.message, 
				code: result.code,
				contractorsCount: contractors.length
			});
			throw new Error(result.message || 'Failed to save contractors');
		}
		console.log('[electron-bridge] Contractors saved successfully to IPC', { count: contractors.length });
	} catch (error) {
		console.error('[electron-bridge] IPC call failed (unexpected error):', error);
		throw error; // Пробрасываем ошибку, чтобы можно было обработать
	}
}

export async function deactivateContractorOnDisk(id: string): Promise<number> {
	if (!window.crm) return 0;
	try {
		const result = await window.crm.deactivateContractor(id);
		if (!result.ok) {
			console.warn('[electron-bridge] Deactivate contractor returned error response', { 
				message: result.message, 
				code: result.code 
			});
			return 0;
		}
		const tasksReturned = result.data?.tasksReturned || 0;
		console.log('[electron-bridge] Contractor deactivated successfully', { id, tasksReturned });
		return tasksReturned;
	} catch (error) {
		console.error('[electron-bridge] IPC call failed (unexpected error):', error);
		return 0;
	}
}

export async function deleteContractorOnDisk(id: string): Promise<void> {
	if (!window.crm) return;
	try {
		const result = await window.crm.deleteContractor(id);
		if (!result.ok) {
			console.warn('[electron-bridge] Delete contractor returned error response', { 
				message: result.message, 
				code: result.code 
			});
			throw new Error(result.message || 'Failed to delete contractor');
		}
		console.log('[electron-bridge] Contractor deleted successfully', { id });
	} catch (error) {
		console.error('[electron-bridge] IPC call failed (unexpected error):', error);
		throw error;
	}
}

export async function getTaskAssigneeHistory(taskId: string): Promise<TaskAssigneeHistory[]> {
	if (!window.crm) return [];
	try {
		const result = await window.crm.getTaskAssigneeHistory(taskId);
		if (!result.ok) {
			console.error('Failed to get task assignee history:', result.message);
			return [];
		}
		return result.data || [];
	} catch (error) {
		console.error('IPC call failed:', error);
		return [];
	}
}

export async function getContractorAssigneeHistory(contractorId: string): Promise<TaskAssigneeHistory[]> {
	if (!window.crm) return [];
	try {
		const result = await window.crm.getContractorAssigneeHistory(contractorId);
		if (!result.ok) {
			console.error('Failed to get contractor assignee history:', result.message);
			return [];
		}
		return result.data || [];
	} catch (error) {
		console.error('IPC call failed:', error);
		return [];
	}
}

export async function saveCustomersToDisk(customers: Customer[]): Promise<void> {
	if (!window.crm) return;
	try {
		if (!Array.isArray(customers)) {
			console.error('[electron-bridge] saveCustomersToDisk: customers is not an array', typeof customers);
			return;
		}
		// window.crm.saveCustomers уже оборачивает customers в { customers }, поэтому передаем массив напрямую
		const result = await window.crm.saveCustomers(customers);
		if (!result.ok) {
			// НЕ бросаем исключение! Просто логируем предупреждение
			// Domain-сервис должен был нормализовать данные, но если ошибка всё равно вернулась,
			// значит данные действительно невалидны - просто пропускаем сохранение
			console.warn('[electron-bridge] Save customers returned error response (data not saved)', { 
				code: result.code, 
				message: result.message,
				...(result as any).error ? { error: (result as any).error } : {}
			});
			return; // Ничего не сохраняем, но не падаем
		}
		// Успешное сохранение - ничего не делаем (void)
	} catch (error) {
		// Только реальные исключения (network, IPC channel errors) логируем как ошибки
		console.error('[electron-bridge] IPC call failed (unexpected error):', error);
	}
}

export async function loadGoalsFromDisk(): Promise<{ goals: Goal[]; monthlyFinancialGoals: MonthlyFinancialGoal[]; credits: Credit[] }> {
	const fallback = { goals: [], monthlyFinancialGoals: [], credits: [] };
	if (!window.crm) return fallback;
	try {
		const result = await window.crm.loadGoals();
		if (!result.ok) {
			console.error('Failed to load goals:', result.message);
			return fallback;
		}
		return result.data;
	} catch (error) {
		console.error('IPC call failed:', error);
		return fallback;
	}
}

export async function saveGoalsToDisk(data: { goals: Goal[]; monthlyFinancialGoals: MonthlyFinancialGoal[]; credits?: Credit[] }): Promise<void> {
	if (!window.crm) return;
	try {
		await unwrap(window.crm.saveGoals(data));
	} catch (error) {
		console.error('Failed to save goals:', error);
	}
}

export async function loadSettingsFromDisk(): Promise<Settings | null> {
	if (!window.crm) return null;
	try {
		const result = await window.crm.loadSettings();
		if (!result.ok) {
			console.error('[electron-bridge] Failed to load settings:', result.message);
			return null;
		}
		let data = result.data;
		
		// КРИТИЧНО: Извлекаем данные из обернутой структуры, если они обернуты
		// Это может произойти, если IPC обработчик не извлек данные правильно
		if (data && typeof data === 'object' && 'settings' in data) {
			const nestedSettings = (data as any).settings;
			// Проверяем, что это действительно настройки (есть характерные поля)
			const hasNestedData = nestedSettings && typeof nestedSettings === 'object' && 
			    ('currency' in nestedSettings || 'holidays' in nestedSettings || 'customWeekends' in nestedSettings);
			const hasRootData = 'currency' in data || 'holidays' in data || 'customWeekends' in data;
			
			if (hasNestedData && !hasRootData) {
				console.warn('[electron-bridge] Found wrapped settings structure, unwrapping...');
				console.warn('[electron-bridge] Nested data:', {
					hasHolidays: !!(nestedSettings as any).holidays,
					holidaysCount: (nestedSettings as any).holidays?.length || 0,
					hasCustomWeekends: !!(nestedSettings as any).customWeekends,
					customWeekendsCount: (nestedSettings as any).customWeekends?.length || 0,
				});
				data = nestedSettings as Settings;
			}
		}
		
		console.log('[electron-bridge] ===== LOADED FROM IPC =====');
		console.log('[electron-bridge] data:', data);
		console.log('[electron-bridge] holidays:', data?.holidays);
		console.log('[electron-bridge] holidaysCount:', data?.holidays?.length || 0);
		console.log('[electron-bridge] customWeekends:', data?.customWeekends);
		console.log('[electron-bridge] customWeekendsCount:', data?.customWeekends?.length || 0);
		console.log('[electron-bridge] excludedWeekends:', data?.excludedWeekends);
		console.log('[electron-bridge] excludedWeekendsCount:', data?.excludedWeekends?.length || 0);
		console.log('[electron-bridge] ============================');
		return data;
	} catch (error) {
		console.error('[electron-bridge] Failed to load settings:', error);
		return null;
	}
}

export async function saveSettingsToDisk(settings: Settings): Promise<void> {
	if (!window.crm) return;
	try {
		// КРИТИЧНО: Проверяем наличие критичных данных перед сохранением
		const hasCriticalData = (settings.holidays && settings.holidays.length > 0) ||
		                        (settings.customWeekends && settings.customWeekends.length > 0) ||
		                        (settings.excludedWeekends && settings.excludedWeekends.length > 0) ||
		                        (settings.weekendTasks && Object.keys(settings.weekendTasks).length > 0);
		
		// Логируем перед сохранением для отладки
		console.log('[electron-bridge] Saving settings:', {
			hasHolidays: !!settings.holidays,
			holidaysCount: settings.holidays?.length || 0,
			hasCustomWeekends: !!settings.customWeekends,
			customWeekendsCount: settings.customWeekends?.length || 0,
			hasExcludedWeekends: !!settings.excludedWeekends,
			excludedWeekendsCount: settings.excludedWeekends?.length || 0,
			hasWeekendTasks: !!settings.weekendTasks,
			weekendTasksKeys: settings.weekendTasks ? Object.keys(settings.weekendTasks).length : 0,
			hasCriticalData,
		});
		
		// Если критичные данные отсутствуют, но мы пытаемся сохранить - это подозрительно
		// Но не блокируем сохранение, так как пользователь мог их очистить намеренно
		if (!hasCriticalData) {
			console.warn('[electron-bridge] WARNING: Saving settings without critical data!');
		}
		
		const result = await window.crm.saveSettings(settings);
		if (!result.ok) {
			// НЕ бросаем исключение! Просто логируем предупреждение
			console.warn('[electron-bridge] Save settings returned error response (data not saved)', { 
				message: result.message, 
				code: result.code 
			});
			return; // Ничего не сохраняем, но не падаем
		}
		// Успешное сохранение - логируем для отладки
		console.log('[electron-bridge] Settings saved successfully', {
			holidaysCount: settings.holidays?.length || 0,
			customWeekendsCount: settings.customWeekends?.length || 0,
			excludedWeekendsCount: settings.excludedWeekends?.length || 0,
			weekendTasksKeys: settings.weekendTasks ? Object.keys(settings.weekendTasks).length : 0,
		});
	} catch (error) {
		// Только реальные исключения (network, IPC channel errors) логируем как ошибки
		console.error('[electron-bridge] IPC call failed (unexpected error):', error);
	}
}

export async function loadCalculationsFromDisk(): Promise<Calculation[]> {
	if (!window.crm) return [];
	try {
		const result = await window.crm.loadCalculations();
		if (!result.ok) {
			console.error('Failed to load calculations:', result.message);
			return [];
		}
		return result.data;
	} catch (error) {
		console.error('IPC call failed:', error);
		return [];
	}
}

export async function saveCalculationsToDisk(calculations: Calculation[]): Promise<void> {
	if (!window.crm) return;
	try {
		await unwrap(window.crm.saveCalculations(calculations));
	} catch (error) {
		console.error('Failed to save calculations:', error);
	}
}

export async function loadTaxesFromDisk(): Promise<TaxPaidFlag[]> {
	if (!window.crm) return [];
	try {
		const result = await window.crm.loadTaxes();
		if (!result.ok) {
			console.error('Failed to load taxes:', result.message);
			return [];
		}
		return result.data;
	} catch (error) {
		console.error('IPC call failed:', error);
		return [];
	}
}

export async function saveTaxesToDisk(taxes: TaxPaidFlag[]): Promise<void> {
	if (!window.crm) return;
	try {
		await unwrap(window.crm.saveTaxes(taxes));
	} catch (error) {
		console.error('Failed to save taxes:', error);
	}
}

export async function loadIncomesFromDisk(): Promise<Income[]> {
	if (!window.crm) return [];
	try {
		const result = await window.crm.loadIncomes();
		if (!result.ok) {
			console.error('Failed to load incomes:', result.message);
			return [];
		}
		return result.data;
	} catch (error) {
		console.error('IPC call failed:', error);
		return [];
	}
}

export async function saveIncomesToDisk(incomes: Income[]): Promise<void> {
	if (!window.crm) return;
	try {
		await unwrap(window.crm.saveIncomes(incomes));
	} catch (error) {
		console.error('Failed to save incomes:', error);
	}
}

export async function loadExtraWorkFromDisk(): Promise<ExtraWork[]> {
	if (!window.crm) return [];
	try {
		const result = await window.crm.loadExtraWork();
		if (!result.ok) {
			console.error('Failed to load extra work:', result.message);
			return [];
		}
		return result.data;
	} catch (error) {
		console.error('IPC call failed:', error);
		return [];
	}
}

export async function saveExtraWorkToDisk(extraWorks: ExtraWork[]): Promise<void> {
	if (!window.crm) return;
	try {
		await unwrap(window.crm.saveExtraWork(extraWorks));
	} catch (error) {
		console.error('Failed to save extra work:', error);
	}
}

export async function selectAvatarFile(): Promise<string | null> {
	if (!window.crm) return null;
	try {
		return await window.crm.selectAvatar();
	} catch {
		return null;
	}
}

export async function selectCsvFile(): Promise<string | null> {
	if (!window.crm) {
		console.error('window.crm is not available');
		return null;
	}
	try {
		const result = await window.crm.selectCsvFile();
		console.log('selectCsvFile result:', result);
		return result;
	} catch (error) {
		console.error('Error in selectCsvFile:', error);
		return null;
	}
}

export async function readCsvFile(filePath: string): Promise<string | null> {
	if (!window.crm) return null;
	try {
		return await window.crm.readCsvFile(filePath);
	} catch {
		return null;
	}
}

export async function saveCsvFile(content: string, defaultFileName?: string): Promise<string | null> {
	if (!window.crm) {
		console.error('saveCsvFile: window.crm not available');
		return null;
	}
	try {
		console.log('saveCsvFile: calling window.crm.saveCsvFile');
		const result = await window.crm.saveCsvFile(content, defaultFileName);
		console.log('saveCsvFile: result:', result);
		return result;
	} catch (error) {
		console.error('saveCsvFile: error:', error);
		return null;
	}
}

export async function selectFiles(): Promise<string[] | null> {
	if (!window.crm) return null;
	try {
		return await window.crm.selectFiles();
	} catch {
		return null;
	}
}

export async function getTaskFilesDir(taskId: string): Promise<string | null> {
	if (!window.crm) return null;
	try {
		return await window.crm.getTaskFilesDir(taskId);
	} catch {
		return null;
	}
}

export async function copyFileToTaskDir(sourcePath: string, destPath: string): Promise<boolean> {
	if (!window.crm) return false;
	try {
		return await window.crm.copyFile(sourcePath, destPath);
	} catch {
		return false;
	}
}

export async function getFileSize(filePath: string): Promise<number | null> {
	if (!window.crm) return null;
	try {
		return await window.crm.getFileSize(filePath);
	} catch {
		return null;
	}
}

export async function openFile(filePath: string): Promise<IpcResult<void>> {
	if (!window.crm) {
		return { ok: false, code: 'NO_API', message: 'window.crm not available' };
	}
	try {
		return await window.crm.openFile(filePath);
	} catch (error) {
		return { ok: false, code: 'ERROR', message: error instanceof Error ? error.message : String(error) };
	}
}

export async function downloadFile(sourcePath: string, defaultFileName?: string): Promise<IpcResult<{ path: string }>> {
	if (!window.crm) {
		return { ok: false, code: 'NO_API', message: 'window.crm not available' };
	}
	try {
		return await window.crm.downloadFile(sourcePath, defaultFileName);
	} catch (error) {
		return { ok: false, code: 'ERROR', message: error instanceof Error ? error.message : String(error) };
	}
}

export async function renameFile(filePath: string, newFileName: string): Promise<IpcResult<{ path: string }>> {
	if (!window.crm) {
		return { ok: false, code: 'NO_API', message: 'window.crm not available' };
	}
	try {
		return await window.crm.renameFile(filePath, newFileName);
	} catch (error) {
		return { ok: false, code: 'ERROR', message: error instanceof Error ? error.message : String(error) };
	}
}

export async function showNotification(title: string, body: string): Promise<void> {
	if (!window.crm) return;
	try {
		await window.crm.showNotification(title, body);
	} catch {
		// ignore
	}
}

export async function openExternalUrl(url: string): Promise<IpcResult<void>> {
	if (!window.crm) {
		return { ok: false, code: 'NO_API', message: 'window.crm not available' };
	}
	try {
		return await window.crm.openExternalUrl(url);
	} catch (error) {
		return { ok: false, code: 'ERROR', message: error instanceof Error ? error.message : String(error) };
	}
}

export async function openDatabase(): Promise<IpcResult<void>> {
	if (!window.crm) {
		return { ok: false, code: 'NO_API', message: 'window.crm not available' };
	}
	try {
		return await window.crm.openDatabase();
	} catch (error) {
		return { ok: false, code: 'ERROR', message: error instanceof Error ? error.message : String(error) };
	}
}

export async function getDatabasePath(): Promise<string | null> {
	if (!window.crm) return null;
	try {
		return await window.crm.getDatabasePath();
	} catch {
		return null;
	}
}




